package com.example.miniproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    Button btnDashboardCreateYourGroup, btnDashboardDetailsOfProject, btnDashboardAddNewProject;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnDashboardCreateYourGroup = findViewById(R.id.btnDashboardCreateYourGroup);
        btnDashboardDetailsOfProject = findViewById(R.id.btnDashboardDetailsOfProject);
        btnDashboardAddNewProject = findViewById(R.id.btnDashboardAddNewProject);

        btnDashboardAddNewProject.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, ProjectDetails.class);
                startActivity(intent);
            }
        });

        btnDashboardCreateYourGroup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, ProjectDetails.class);
                startActivity(intent);
            }
        });

    }
}