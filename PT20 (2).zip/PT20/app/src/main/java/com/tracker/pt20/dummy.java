package com.tracker.pt20;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class dummy extends AppCompatActivity {
    Button group;

    EditText addnewpro;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dummy);
        group = findViewById(R.id.create_grp);
        group.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(dummy.this,"You can create your grp",Toast.LENGTH_LONG).show();
                openMain();
            }
        });

        addnewpro = findViewById(R.id.addnewpro);
        addnewpro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent crg = new Intent(dummy.this,create_pro.class);
                startActivity(crg);
            }
        });

    }
    public void openMain(){
        Intent main1 = new Intent(this,MainActivity.class);
        startActivity(main1);
    }

}