package com.tracker.pt20;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;

public class MainActivity extends AppCompatActivity {

    Button loginbtn;
    Button signupbtn;
    FirebaseAuth authfire;
    private DrawerLayout dlayout;
    private NavigationView nview;
    Menu menu;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        authfire = FirebaseAuth.getInstance();


        loginbtn = findViewById(R.id.Loginbtn);
        loginbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openLoginPage();
            }
        });
        signupbtn = findViewById(R.id.signup);
        signupbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openSignUpPage();
            }
        });
    }
    public void openLoginPage() {
        Intent intent = new Intent(this, Login_Page.class);
        startActivity(intent);
    }
    public void openSignUpPage(){
        Intent signups = new Intent(this,Signup_Page.class);
        startActivity(signups);
    }
    public void Logoutm(){


                FirebaseAuth.getInstance().signOut();
                Intent main = new Intent(MainActivity.this,
                        MainActivity.class);
                startActivity(main);
    }
    public void dashboard(){



        Intent dashb = new Intent(MainActivity.this,
                dummy.class);
        startActivity(dashb);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater=getMenuInflater();
        inflater.inflate(R.menu.top_nav,menu);

        

        return true;
    }

    @Override
    public boolean onOptionsItemSelected( MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.homee) {
            Toast.makeText(this, "Go to Dashboard", Toast.LENGTH_SHORT).show();
            dashboard();
            return true;
        } else if (id == R.id.logn) {
            Logoutm();
            return true;
        } else if (id == R.id.helpi) {
            return true;
        }else if(id==R.id.sugge){
            return true;
        }else{
            return super.onOptionsItemSelected(item);
        }




          }

    }



































