package com.example.project1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Spinner myspinner1 = (Spinner) findViewById(R.id.spinner1);
        Spinner myspinner2 = (Spinner) findViewById(R.id.spinner2);
        Spinner myspinner3 = (Spinner) findViewById(R.id.spinner3);
        Spinner myspinner4 = (Spinner) findViewById(R.id.spinner4);
        Spinner myspinner5 = (Spinner) findViewById(R.id.spinner5);


        ArrayAdapter<CharSequence> adapter =  ArrayAdapter.createFromResource(this,R.array.tasktypes, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);


        myspinner1.setAdapter(adapter);
        myspinner1.setOnItemSelectedListener(this);
        myspinner2.setAdapter(adapter);
        myspinner2.setOnItemSelectedListener(this);
        myspinner3.setAdapter(adapter);
        myspinner3.setOnItemSelectedListener(this);
        myspinner4.setAdapter(adapter);
        myspinner4.setOnItemSelectedListener(this);
        myspinner5.setAdapter(adapter);
        myspinner5.setOnItemSelectedListener(this);
    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
        String text=adapterView.getItemAtPosition(i).toString();
        Toast.makeText(adapterView.getContext(), text, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }
}